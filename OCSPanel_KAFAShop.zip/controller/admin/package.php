<?php 

namespace Admin;

class Package extends \Home {

	use \Helper\Package;
	
	protected
		$package;

	function beforeRoute($f3) {
		parent::beforeRoute($f3);
		if ( ! $this->me->isAdmin()) $f3->reroute('/logout');
		$this->package = new \Package;
	}

	function All($f3) {
		$package = $this->package->find();
		$f3->set('package',$package);
		$f3->set('subcontent','admin/packages.html');
	}

	function loadPackage() {
		$f3 = \Base::instance();
		$package = $this->package;
		if ($f3->exists('PARAMS.id')) {
			$id = $f3->get('PARAMS.id');
			$package->load(array('id=? AND active=1',$id));
			$package->reroute('/home/admin/package');
		}
		return $package;
	}
	
	function loadPackage2() {
		$f3 = \Base::instance();
		$package = $this->package;
		if ($f3->exists('PARAMS.id')) {
			$id = $f3->get('PARAMS.id');
			$package->load(array('id=? AND active=0',$id));
			$package->reroute('/home/admin/package');
		}
		return $package;
	}

	function Id($f3) {
		$package = $this->loadPackage();
		$f3->set('package',$package);
		$f3->set('subcontent','admin/package.html');
	}

	function Set($f3) {
		$package = $this->loadPackage();
		if ($package->dry()) {
			$package->load(array('package=?',$f3->get('POST.package')));
			if ( ! $package->dry()) {
				$this->flash('Package already register');
				$f3->reroute('/home/admin/package/add');
			}
		}
		$package->copyFrom('POST');
		$package->active = 1;
		$package->save();
		$this->flash('Saved Success','success');
		$f3->reroute('/home/admin/package/'.$package->id);
	}

	function Lock($f3) {
	$package = $this->loadPackage();
		$package->active = 0;
		$package->save();
		$this->flash('Package Locked','success');
		$f3->reroute('/home/admin/package/');
		
	}
	
	function Unlock($f3) {
	$package = $this->loadPackage2();
		$package->active = 1;
		$package->save();
		$this->flash('Package Unlocked','success');
		$f3->reroute('/home/admin/package/');
		
	}
	
	function Delete($f3) {
		$package = $this->loadPackage();
		$package->erase();
		$this->flash('Package deleted success','success');
		$f3->reroute('/home/admin/package/');
	}
	
	function Edit($f3) {
		$package = $this->loadPackage();
		$f3->set('package',$package);
		$f3->reroute('/home/admin/package/'.$package->id);
	}


}