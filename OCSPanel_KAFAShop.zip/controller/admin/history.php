<?php 

namespace Admin;

class History extends \Home {

	use \Helper\History;
	
	protected
		$history;

	function beforeRoute($f3) {
		parent::beforeRoute($f3);
		$this->history = new \History;
	}

	function All($f3) {
	$histories = $this->history->find();
	$f3->set('histories',$histories);
	$f3->set('subcontent','admin/history.html');
	}

	function loadHistory() {
		$f3 = \Base::instance();
		$history = $this->history;
		if ($f3->exists('PARAMS.id')) {
			$id = $f3->get('PARAMS.id');
			$history->load(array('id=?',$id));
			$history->reroute('/home/admin/history');
		}
		return $history;
	}

	function Id($f3) {
		$history = $this->loadHistory();
		$f3->set('history',$history);
		$f3->set('subcontent','admin/history.html');
	}

}