<?php

namespace Helper;

trait Package {

	function loadPackage() {
		$f3 = \Base::instance();
		$package = $this->package;
		if ($f3->exists('PARAMS.id',$id)) {
			if ($this->me->isAdmin()) {
				$package->id($id);
				$package->reroute('/home/admin/package');
			} else {
				$package->load(array('id=? AND active=1',$id));
				$package->reroute('/home/member/package');
			}
		}
		return $package;
	}

}