<?php

namespace Helper;

trait History {

	function loadHistory() {
		$f3 = \Base::instance();
		$history = $this->history;
		if ($f3->exists('PARAMS.id',$id)) {
			if ($this->me->isAdmin()) {
				$history->id($id);
				$history->reroute('/home/admin/history');
			} else {
				$history->load(array('id=? AND active=1',$id));
				$history->reroute('/home/member/history');
			}
		}
		return $history;
	}

}