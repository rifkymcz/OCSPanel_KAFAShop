<?php

namespace Helper;

trait Buyer {

	function loadBuyer() {
		$f3 = \Base::instance();
		$buyer = $this->buyer;
		if ($f3->exists('PARAMS.id',$id)) {
			if ($this->me->isAdmin()) {
				$buyer->id($id);
				$buyer->reroute('/home/admin/buyer');
			} else {
				$buyer->load(array('id=? AND active=1',$id));
				$buyer->reroute('/home/member/buyer');
			}
		}
		return $buyer;
	}

}