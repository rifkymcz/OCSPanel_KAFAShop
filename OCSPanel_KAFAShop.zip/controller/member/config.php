<?php 

namespace Member;

class Config extends \Home {

	use \Helper\Server;

	protected
		$seller;

	function loadSeller() {
		$f3 = \Base::instance();
		$seller = $this->seller;
		if ($f3->exists('PARAMS.id')) {
			$id = $f3->get('PARAMS.id');
			$seller->load(array('id=? AND type=2',$id));
			$seller->reroute('/home/member/wallet');
		}
		return $seller;
	}
	
		function Id($f3) {
		$seller = $this->loadSeller();
		$f3->set('seller',$seller);
		$f3->set('subcontent','member/wallet.html');
	}

	
	function Wallet($f3) {

		$f3->set('subcontent','member/wallet.html');
	}
	
	function Deposit2($f3) {
	    $f3 = \Base::instance();
	    $post 	= $f3->get('POST');	    
        $dsn = $f3->DB_SET;
        $db_user = $f3->DB_USER;
        $db_pass = $f3->DB_PASS;
        $db = new \DB\SQL($dsn,$db_user,$db_pass);
        $user = new \DB\SQL\Mapper($db,'user');
        $hist = new \DB\SQL\Mapper($db,'history');
        $hist1 = new \DB\SQL\Mapper($db,'history');   
		if (($this->me->saldo)<$post['deposit']){
			$this->flash('Your Balance is not enough, Contact Administrator');
		   	$f3->reroute('/home/member/wallet');
		}
        if ($user->dry()) {
	    	$user->load(array('username=?',$post['username']));
		    if ( ! $user->dry()) {
			   $user->saldo = ($user->saldo + $post['deposit']);
	    	   $user->save();
	    	   $this->me->saldo = $this->me->saldo-$post['deposit'];
	    	   $this->me->save();
	    	   
	    	   $hist->user = $this->me->username;
	    	   $hist->description = "Transfer Wallet to ". $post['username']. " Success (RM ". $post['deposit'] . ")";
	    	   $hist->date = $post['date'];
	    	   $hist->active = 1;
	    	   $hist->save();  
	    	   $hist1->user = $post['username'];
	    	   $hist1->description = "Received Wallet (RM ". $post['deposit'] . ") from ".$this->me->username;
	    	   $hist1->date = $post['date'];
	    	   $hist1->active = 1;
	    	   $hist1->save();   
	    	   $this->flash('Wallet transfer done','success');
	    	   $f3->reroute('/home/member/wallet');
	    	    }
    			$this->flash('User not exist!!');
            	$f3->reroute('/home/member/wallet');
           }
	
	}

}