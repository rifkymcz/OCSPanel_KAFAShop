<?php 

namespace Member;

class Server extends \Home {

	use \Helper\Server;

	protected
		$server;

	function beforeRoute($f3) {
		parent::beforeRoute($f3);
		if ( $this->me->isAdmin()) $f3->reroute('/home/admin/server/');
		$this->server = new \Server;
	}

	function All($f3) {
		$server = $this->server->find(array('active=1'));
		$f3->set('servers',$server);
		$f3->set('subcontent','member/servers.html');
	}

	function Id($f3) {
		$server = $this->loadServer();
		$f3->set('server',$server);
		$f3->set('subcontent','member/server.html');
	}

	function Buy($f3) {
		$server = $this->loadServer();
		$account = new \Webmin($server);
		$post = $f3->get('POST');	
	       $dsn = $f3->DB_SET;
 	       $db_user = $f3->DB_USER;
	       $db_pass = $f3->DB_PASS;
	       $db = new \DB\SQL($dsn,$db_user,$db_pass);
	       $hist = new \DB\SQL\Mapper($db,'history');
		
		if (($saldo = $this->me->saldo)<$post['day']) {
			$this->flash('Your Balance is not enough, Contact Administrator');
			$f3->reroute($f3->get('URI'));
		}
		if ( ! $account->check($f3->get('POST.user'))) {
			$this->flash('User Already Registered, Try another User');
			$f3->reroute($f3->get('URI'));
		}
		$account->copyFrom('POST');
		$account->real = $this->me->username;
		if ($f3->exists('POST.pass',$pass)) {
			if ( ! \Check::Confirm('POST.pass')) {
				$this->flash('Confirm Password Mismatch');
				$f3->reroute($f3->get('URI'));
			}
			$account->pass = $account->crypt($pass);
		}
        $hariaktif = $post['vali'];
        $extra = 0;
        $hariextra = $hariaktif + $extra;
		$active = date("Y/m/d",strtotime("+$hariextra days"));
		$account->expire = \Webmin::exp_encode($active);
		if( ! $account->save()) {
			$this->flash('Failed, Try agian');
			$f3->reroute($f3->get('URI'));
		}
		$this->me->saldo = $this->me->saldo-$post['day'];
		$this->me->save();
	    	   $hist->user = $this->me->username;
	    	   $hist->description = "Purchased (". $post['produk'] . ") for ". $post['vali'] ." day";
	    	   $hist->date = $post['date'];
	    	   $hist->active = 1;
	    	   $hist->save();
		$this->flash('Account Purchases Successful','success');
		$f3->set('SESSION.uid',$account->uid);
		$f3->set('SESSION.pass',$pass);
		$f3->reroute($f3->get('URI').'/success');
	}

	function Report($f3) {
		$server = $this->loadServer();
		if ( ! $f3->exists('SESSION.uid',$uid))
			$f3->reroute('/home/member/server');
		$account = new \Webmin($server);
		$account->load($uid);
		$account->pass = $f3->get('SESSION.pass');
		$f3->set('server',$server);
		$f3->set('user',$account);
		$f3->set('subcontent','member/account.html');
		$f3->clear('SESSION.uid');
		$f3->clear('SESSION.pass');
	}
		
	function Renew($f3) {
	    $this->flash('Username listed below were registered by you','success');
		$server = $this->loadServer();
		$acc2 = $this->loadUser($server);
		$acc= $this->me->username;
		$account = new \Webmin($server);
		$accounts = $account->finding($acc);
		$f3->set('server',$server);
		$f3->set('users',$accounts);
		$f3->set('subcontent','member/renew.html');
	}
	function loadUser($server) {
		$app = \Base::instance();
		$webmin = new \webmin($server);
		if ($app->exists('PARAMS.uid',$uid)) {
			$webmin->load($uid);
			$webmin->reroute('/home/member/server/'.$server->id.'/renew/');
		}
		return $webmin;
	}
	function Renewal($f3) {
		$server = $this->loadServer();
		$account = $this->loadUser($server);
		$f3->set('server',$server);
		$f3->set('user',$account);
		$f3->set('subcontent','member/renewal.html');
	}
	
		function Apply($f3) {
		$server = $this->loadServer();
		$account = $this->loadUser($server);
		$account->copyFrom('POST');
		$post = $f3->get('POST');	
	       $dsn = $f3->DB_SET;
 	       $db_user = $f3->DB_USER;
	       $db_pass = $f3->DB_PASS;
	       $db = new \DB\SQL($dsn,$db_user,$db_pass);
	       $hist = new \DB\SQL\Mapper($db,'history');	
		if (($saldo = $this->me->saldo)<$post['day']) {
			$this->flash('Your Balance is not enough, Contact Administrator');
			$f3->reroute('/home/member/server/'.$server->id.'/renew/'.$account->uid.'/renewal/');
		}
		if ($account->dry()) {
			if ( ! $account->check($f3->get('POST.user'))) {
				$this->flash('Username already being used by others');
				$f3->reroute('/home/member/server/'.$server->id.'/renew/'.$account->uid.'/renewal/');
			}
			$account->real = $this->me->username;
		}
		
		if ($f3->exists('POST.pass',$pass)) {
			if ( ! \Check::Confirm('POST.pass')) {
				$this->flash('Confirm Password Mismatch');
				$f3->reroute('/home/member/server/'.$server->id.'/renew/'.$account->uid.'/renewal/');
			}
			$account->pass = $account->crypt($pass);
		}
		if (! $f3->exists('POST.exp',$exp)) {
	 $hariaktif = $post['vali'];
        $extra = 0;
        $hariextra = $hariaktif + $extra;
	 $active = date("Y/m/d",strtotime("+$hariextra days"));
		
		$account->expire = \Webmin::exp_encode($active);
		$account->save();
		$this->me->saldo = $this->me->saldo-$post['day'];
		$this->me->save();
	    	   $hist->user = $this->me->username;
	    	   $hist->description = "Renew account (". $post['renuser'] . ")";
	    	   $hist->date = $post['date'];
	    	   $hist->active = 1;
	    	   $hist->save();	
		
		}
		$this->flash('User Renewal Successful','success');
		$f3->reroute('/home/member/server/'.$server->id.'/renew/'.$account->uid.'/renewal/');
	}

	function Block($f3) {
		$server = $this->loadServer();
		$account = $this->loadUser($server);
		if ($f3->exists('PARAMS.active',$active)) {
			if ($active)
				$account->pass = ltrim($account->pass,'!');
			else
				$account->pass = '!'.$account->pass;
		}
		$account->save();
		$this->flash('Successfully','success');
		$f3->reroute('/home/member/server/'.$server->id.'/renew/'.$account->uid.'/renewal/');
	}	
	
		function Remove($f3) {
		$server = $this->loadServer();
		$account = $this->loadUser($server);
		$account->erase();
		$this->flash('Account deleted Success','success');
		$f3->reroute('/home/member/server/'.$server->id.'/renew');
	}
	
		function PasswordC($f3) {

	}

	
}