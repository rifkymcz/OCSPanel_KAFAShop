<?php 

namespace Member;

class Buyer extends \Home {

	use \Helper\Buyer;
	
	protected
		$buyer;

	function beforeRoute($f3) {
		parent::beforeRoute($f3);
		$this->buyer = new \Buyer;
	}

	function All($f3) {
	$username = $this->me->username;
	$buyers = $this->buyer->find(array('username=?',$username));
	$f3->set('buyers',$buyers);
	$f3->set('subcontent','member/buyers.html');
	}

	function loadBuyer() {
		$f3 = \Base::instance();
		$buyer = $this->buyer;
		if ($f3->exists('PARAMS.id')) {
			$id = $f3->get('PARAMS.id');
			$buyer->load(array('id=?',$id));
			$buyer->reroute('/home/member/buyer');
		}
		return $buyer;
	}

	function Id($f3) {
		$buyer = $this->loadBuyer();
		$f3->set('seller',$buyer);
		$f3->set('subcontent','member/buyer.html');
	}
		function Resit($f3) {
		$buyer = $this->loadBuyer();
		$f3->set('buyer',$buyer);
		$this->flash('Screenshot butiran dan send kepada admin untuk proses delivery.','success');
		$f3->set('subcontent','member/resit.html');
	}
	

}