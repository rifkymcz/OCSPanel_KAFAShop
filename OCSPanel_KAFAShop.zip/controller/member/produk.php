<?php 

namespace Member;

class Produk extends \Home {

	use \Helper\Produk;

	protected
		$produk;

	function beforeRoute($f3) {
		parent::beforeRoute($f3);
		if ( $this->me->isAdmin()) $f3->reroute('/home/admin/produk/');
		$this->produk = new \Produk;
	}

	function All($f3) {
		$produk = $this->produk->find(array('active=1'));
		$f3->set('produk',$produk);
		$f3->set('subcontent','member/produks.html');
	}

	function Id($f3) {
		$produk = $this->loadProd();
		$f3->set('produk',$produk);
		$f3->set('subcontent','member/produk.html');
	}

	function Buy($f3) {
	 $produk = $this->loadProd();
	 $post = $f3->get('POST');
        $dsn = $f3->DB_SET;
        $db_user = $f3->DB_USER;
        $db_pass = $f3->DB_PASS;
        $db = new \DB\SQL($dsn,$db_user,$db_pass);
        $buyer = new \DB\SQL\Mapper($db,'buyer');
        $hist = new \DB\SQL\Mapper($db,'history');

        if (($this->me->saldo)<$post['price']){
		$this->flash('Your wallet balance is not enough, contact admin to reload');
		$f3->reroute('/home/member/produk');
		}
        $db->begin();
	 $buyer->username = $this->me->username;
	 $buyer->product = $post['produk'];
        $buyer->price = $post['price'];
        $buyer->validity = $post['validity'];
        $buyer->status = "Pending";
        $buyer->active = 1;
        $buyer->save();
	 $this->me->saldo = $this->me->saldo-$post['price'];
	 $this->me->save();
	    	   $hist->user = $this->me->username;
	    	   $hist->description = "Purchased (". $post['produk'] . ")";
	    	   $hist->date = $post['date'];
	    	   $hist->active = 1;
	    	   $hist->save();   
		$db->commit();
        $this->flash('Congratulation. You have buy a product. ','success');
		$f3->reroute('/home/member/produk');
		
        
	}
	


}
