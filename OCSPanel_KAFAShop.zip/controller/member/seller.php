<?php 

namespace Member;

class Seller extends \Home {

	protected
		$seller;

	function beforeRoute($f3) {
		parent::beforeRoute($f3);
		$this->seller = new \User;
	}

	function All($f3) {
	$upline = $this->me->username;
		$sellers = $this->seller->find(array('upline=? AND type>=2',$upline));
		$f3->set('sellers',$sellers);
		$f3->set('subcontent','member/sellers.html');
	}

	function loadSeller() {
		$f3 = \Base::instance();
		$seller = $this->seller;
		if ($f3->exists('PARAMS.id')) {
			$id = $f3->get('PARAMS.id');
			$seller->load(array('id=? AND type=2',$id));
			$seller->reroute('/home/member/seller');
		}
		return $seller;
	}

	function Id($f3) {
		$seller = $this->loadSeller();
		$f3->set('seller',$seller);
		$f3->set('subcontent','member/seller.html');
	}

}