<?php

class Buyer extends Model{

 	function __construct() {
		parent::__construct('buyer');
	}

    function id($id) {
    	$this->load(array('id=?',$id));
    	return $this;
    }

    function reroute($url) {
    	if ($this->dry()) Base::instance()->reroute($url);
    	return $this;
    }
}